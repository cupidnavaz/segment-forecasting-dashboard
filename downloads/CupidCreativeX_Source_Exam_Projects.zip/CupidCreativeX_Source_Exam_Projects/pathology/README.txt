# CupidCreativeX Pathology Exam Project

Source:
Textbook of Pathology — Sixth Revised Edition

This standalone project preserves the exam-dashboard behavior of the supplied Nclexmodern.html template while replacing its original NCLEX question bank, topics, and answers with source-specific material.

Included:
- Source-specific chapter/topic selector
- Source-specific question bank
- Multiple choice
- Select-all-that-apply
- Ordered response
- Drag-and-drop matching
- Full-screen exam modal
- Countdown timer
- Progress tracking
- Auto-scoring
- Answer review and rationales
- Local profile/avatar
- Local exam history
- Performance chart
- Printable review / PDF printing flow
- Source-isolated localStorage keys

The question content is derived from the supplied source's contents and selected source excerpts; no original NCLEX question bank is retained.
