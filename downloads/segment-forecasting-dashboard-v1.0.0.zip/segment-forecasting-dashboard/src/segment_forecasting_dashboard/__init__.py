"""Segment Forecasting Dashboard package."""

__version__ = "1.0.0"
